from django.contrib import admin
from .models import Country_data

admin.site.register(Country_data)
